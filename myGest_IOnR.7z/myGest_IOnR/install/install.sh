#!/bin/bash

# Vérifier si le script est exécuté en tant que root
if [ "$EUID" -ne 0 ]; then
    echo "Veuillez exécuter ce script en tant que root."
    exit 1
fi

# Fonction pour installer un paquet si nécessaire
install_package() {
    local package=$1
    if ! dpkg -s "$package" &>/dev/null; then
        echo "Installation de $package..."
        apt update && apt install -y "$package"
    else
        echo "$package est déjà installé."
    fi
}

# Installer lolcat, figlet et mariadb-server
install_package "lolcat"
install_package "figlet"
install_package "mariadb-server"

# Affichage stylisé pour débuter la configuration
figlet "MariaDB Config" | lolcat

# Demander à l'utilisateur d'entrer le nom d'utilisateur MariaDB
read -p "Entrez le nom d'utilisateur MariaDB à créer : " MYSQL_USER

# Valider que le nom d'utilisateur n'est pas vide
if [ -z "$MYSQL_USER" ]; then
    echo "Erreur : Le nom d'utilisateur ne peut pas être vide." | lolcat
    exit 1
fi

# Demander le mot de passe MariaDB
read -sp "Entrez le mot de passe pour '$MYSQL_USER' : " MYSQL_PASS
echo
read -sp "Confirmez le mot de passe : " MYSQL_PASS_CONFIRM
echo

# Vérifier si les mots de passe correspondent
if [ "$MYSQL_PASS" != "$MYSQL_PASS_CONFIRM" ]; then
    echo "Erreur : Les mots de passe ne correspondent pas." | lolcat
    exit 1
fi

# Créer l'utilisateur et attribuer les droits
echo "Création de l'utilisateur MariaDB et attribution des droits..." | lolcat

mysql -u root <<EOF
CREATE USER IF NOT EXISTS '$MYSQL_USER'@'localhost' IDENTIFIED BY '$MYSQL_PASS';
GRANT ALL PRIVILEGES ON *.* TO '$MYSQL_USER'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;
EOF

# Vérifier si la commande MySQL a réussi
if [ $? -eq 0 ]; then
    echo "L'utilisateur '$MYSQL_USER' a été créé avec succès et a reçu tous les droits." | lolcat
else
    echo "Erreur lors de la création de l'utilisateur MariaDB." | lolcat
    exit 1
fi

# Fin de l'installation
figlet "Installation Complète!" | lolcat
echo "MariaDB est configuré avec l'utilisateur '$MYSQL_USER'." | lolcat

