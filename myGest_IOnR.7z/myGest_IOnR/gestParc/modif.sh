#!/bin/bash

# Demande le mot de passe une seule fois
read -sp "Entrez le mot de passe MySQL : " mysql_password
echo

while true; do
    # Liste toutes les bases de données
    echo "Liste des bases de données :"
    mysql -u votre_utilisateur -p"$mysql_password" -e "SHOW DATABASES;"

    # Demande à l'utilisateur de choisir une base de données
    read -p "Entrez le nom de la base de données que vous souhaitez gérer (ou 'exit' pour quitter) : " db_name

    # Permet de quitter le script
    if [[ "$db_name" == "exit" ]]; then
        echo "Au revoir !"
        break
    fi

    # Vérifie si la base de données existe
    if mysql -u votre_utilisateur -p"$mysql_password" -e "USE $db_name;" 2>/dev/null; then
        echo "Vous avez choisi la base de données '$db_name'."

        # Demande à l'utilisateur de choisir une action
        echo "Que souhaitez-vous faire ?"
        echo "1. Modifier un équipement dans la table 'equipements'"
        echo "2. Ajouter un nouvel équipement dans la table 'equipements'"
        read -p "Entrez le numéro de l'action souhaitée : " action_choice

        case $action_choice in
            1)  # Modification d'un équipement
                read -p "Entrez l'ID de l'équipement à modifier : " equip_id
                equip_exists=$(mysql -u votre_utilisateur -p"$mysql_password" -e "USE $db_name; SELECT COUNT(*) FROM equipements WHERE id = $equip_id;" | tail -n 1)
                if [[ "$equip_exists" -eq 0 ]]; then
                    echo "Erreur : Aucun équipement trouvé avec l'ID '$equip_id'."
                    continue
                fi
                echo "L'équipement avec l'ID '$equip_id' existe."
                echo "Que souhaitez-vous modifier ?"
                echo "1. Modifier le type"
                echo "2. Modifier le nom"
                echo "3. Modifier l'adresse MAC"
                echo "4. Modifier l'adresse IP"
                echo "5. Modifier le masque"
                echo "6. Modifier tous les champs"
                read -p "Entrez le numéro de l'option souhaitée : " mod_choice
                case $mod_choice in
                    1) read -p "Entrez le nouveau type : " new_type
                       mysql -u votre_utilisateur -p"$mysql_password" -e "USE $db_name; UPDATE equipements SET type = '$new_type' WHERE id = $equip_id;"
                       ;;
                    2) read -p "Entrez le nouveau nom : " new_nom
                       mysql -u votre_utilisateur -p"$mysql_password" -e "USE $db_name; UPDATE equipements SET nom = '$new_nom' WHERE id = $equip_id;"
                       ;;
                    3) read -p "Entrez la nouvelle adresse MAC : " new_mac
                       mysql -u votre_utilisateur -p"$mysql_password" -e "USE $db_name; UPDATE equipements SET adresse_mac = '$new_mac' WHERE id = $equip_id;"
                       ;;
                    4) read -p "Entrez la nouvelle adresse IP : " new_ip
                       mysql -u votre_utilisateur -p"$mysql_password" -e "USE $db_name; UPDATE equipements SET adresse_ip = '$new_ip' WHERE id = $equip_id;"
                       ;;
                    5) read -p "Entrez le nouveau masque : " new_mask
                       mysql -u votre_utilisateur -p"$mysql_password" -e "USE $db_name; UPDATE equipements SET masque = '$new_mask' WHERE id = $equip_id;"
                       ;;
                    6) read -p "Entrez le nouveau type : " new_type
                       read -p "Entrez le nouveau nom : " new_nom
                       read -p "Entrez la nouvelle adresse MAC : " new_mac
                       read -p "Entrez la nouvelle adresse IP : " new_ip
                       read -p "Entrez le nouveau masque : " new_mask
                       mysql -u votre_utilisateur -p"$mysql_password" -e "USE $db_name; UPDATE equipements SET type = '$new_type', nom = '$new_nom', adresse_mac = '$new_mac', adresse_ip = '$new_ip', masque = '$new_mask' WHERE id = $equip_id;"
                       ;;
                esac
                echo "Modification réussie."
                ;;
            2)  # Ajout d'un nouvel équipement
                read -p "Entrez l'ID : " id
                read -p "Entrez le type (machine/serveur/switch) : " type
                read -p "Entrez le nom : " nom
                read -p "Entrez l'adresse MAC : " adresse_mac
                read -p "Entrez l'adresse IP : " adresse_ip
                read -p "Entrez le masque de sous-réseau : " masque
                mysql -u votre_utilisateur -p"$mysql_password" -e "USE $db_name; 
                    INSERT INTO equipements (id, type, nom, adresse_mac, adresse_ip, masque) 
                    VALUES ('$id', '$type', '$nom', '$adresse_mac', '$adresse_ip', '$masque');"
                echo "Nouvel équipement ajouté avec succès."
                ;;
            *) echo "Choix invalide." ;;
        esac
    else
        echo "Erreur : La base de données '$db_name' n'existe pas."
    fi
done




     


