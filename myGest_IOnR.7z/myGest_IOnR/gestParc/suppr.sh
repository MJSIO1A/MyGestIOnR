#!/bin/bash

# Demande le mot de passe MySQL une seule fois
read -p "Entrez le nom d'utilisateur MySQL : " DB_USER
read -s -p "Entrez le mot de passe MySQL : " DB_PASS
echo ""

# Affichage des bases de données disponibles
echo "Bases de données disponibles :"
mysql -u "$DB_USER" -p"$DB_PASS" -e "SHOW DATABASES;" | tail -n +2

# Sélection de la base de données
read -p "Entrez le nom de la base de données à utiliser : " DB_NAME

# Vérification de la connexion et de l'existence de la base
if ! mysql -u "$DB_USER" -p"$DB_PASS" -e "USE $DB_NAME;" 2>/dev/null; then
    echo "Erreur : Impossible de se connecter à la base de données '$DB_NAME'."
    exit 1
fi

# Nom de la table
TABLE_NAME="equipements"

# Vérifier si la table existe
TABLE_EXISTS=$(mysql -u "$DB_USER" -p"$DB_PASS" -D "$DB_NAME" -se "SHOW TABLES LIKE '$TABLE_NAME';")
if [ -z "$TABLE_EXISTS" ]; then
    echo "Erreur : La table '$TABLE_NAME' n'existe pas dans la base '$DB_NAME'."
    exit 1
fi

# Affichage des équipements existants avec adresse MAC et masque de sous-réseau
echo "Liste des équipements dans la base '$DB_NAME' :"
mysql -u "$DB_USER" -p"$DB_PASS" -D "$DB_NAME" -e "
    SELECT id, nom, type, adresse_mac, adresse_ip, masque 
    FROM $TABLE_NAME;"

# Demande de l'ID de l'équipement à supprimer
read -p "Entrez l'ID de l'équipement à supprimer : " EQUIP_ID

# Vérifier si l'ID existe
EXISTE=$(mysql -u "$DB_USER" -p"$DB_PASS" -D "$DB_NAME" -se "
    SELECT COUNT(*) FROM $TABLE_NAME WHERE id=$EQUIP_ID;")

if [ "$EXISTE" -eq 0 ]; then
    echo "Erreur : Aucun équipement avec l'ID $EQUIP_ID trouvé."
    exit 1
fi

# Confirmation avant suppression
read -p "Êtes-vous sûr de vouloir supprimer l'équipement ID $EQUIP_ID ? (o/n) : " CONFIRM
if [[ "$CONFIRM" =~ ^[oO]$ ]]; then
    mysql -u "$DB_USER" -p"$DB_PASS" -D "$DB_NAME" -e "
        DELETE FROM $TABLE_NAME WHERE id=$EQUIP_ID;"
    echo "Équipement ID $EQUIP_ID supprimé avec succès."
else
    echo "Suppression annulée."
fi



