#!/bin/bash

# Demande le mot de passe MySQL une seule fois
read -sp "Entrez le mot de passe MySQL : " MYSQL_PASSWORD
echo

# Lister les bases de données disponibles
echo "Bases de données disponibles :"
DB_LIST=$(mysql -u votre_utilisateur -p"$MYSQL_PASSWORD" -e "SHOW DATABASES;" | tail -n +2)
echo "$DB_LIST"
echo ""

# Demande quelle base de données sauvegarder/restaurer
echo "1) Choisir une base de données spécifique"
echo "2) Sauvegarder/Restaurer toutes les bases de données"
echo "3) Quitter"
read -p "Votre choix : " choix_global

if [[ $choix_global -eq 1 ]]; then
    read -p "Entrez le nom de la base de données : " DB_NAME
elif [[ $choix_global -eq 2 ]]; then
    DB_NAME="--all-databases"
else
    echo "Opération annulée."
    exit 0
fi

# Configuration du dossier de sauvegarde
BACKUP_DIR="$HOME/backups"
mkdir -p "$BACKUP_DIR"

echo "-------------- Gestion des sauvegardes --------------"
echo "1) Sauvegarde"
echo "2) Restauration"
echo "3) Quitter"
read -p "Choisissez une option : " choix

case $choix in
    1)  # Sauvegarde
        BACKUP_FILE="$BACKUP_DIR/${DB_NAME}-$(date +'%Y%m%d-%H%M%S').sql"
        echo "Sauvegarde en cours..."
        mysqldump -u votre_utilisateur -p"$MYSQL_PASSWORD" $DB_NAME > "$BACKUP_FILE"

        if [[ $? -eq 0 ]]; then
            echo "Sauvegarde réussie : $BACKUP_FILE"
        else
            echo "Erreur lors de la sauvegarde."
            exit 1
        fi
        ;;
        
    2)  # Restauration avec autocomplétion
        echo "Sauvegardes disponibles :"
        SAVE_FILES=("$BACKUP_DIR"/*.sql)  # Tableau des fichiers de sauvegarde

        if [[ ${#SAVE_FILES[@]} -eq 0 ]]; then
            echo "Aucune sauvegarde disponible."
            exit 1
        fi

        select RESTORE_FILE in "${SAVE_FILES[@]}"; do
            if [[ -n "$RESTORE_FILE" && -f "$RESTORE_FILE" ]]; then
                echo "Restauration en cours..."
                mysql -u votre_utilisateur -p"$MYSQL_PASSWORD" < "$RESTORE_FILE"
                echo "Restauration terminée."
                break
            else
                echo "Sélection invalide, essayez à nouveau."
            fi
        done
        ;;

    3)  # Quitter
        echo "Opération annulée."
        exit 0
        ;;

    *)  # Mauvais choix
        echo "Option invalide."
        exit 1
        ;;
esac











