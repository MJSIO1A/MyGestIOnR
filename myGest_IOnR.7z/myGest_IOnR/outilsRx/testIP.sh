#!/bin/bash

# Nom d'utilisateur MySQL
MYSQL_USER="votre_utilisateur"

# Demander le mot de passe MySQL une seule fois
read -sp "Entrez le mot de passe MySQL : " MYSQL_PASS
echo

# Fonction pour valider une adresse IP
function is_valid_ip() {
    local ip=$1
    local stat=1

    if [[ $ip =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
        IFS='.' read -r -a ip_array <<< "$ip"
        for octet in "${ip_array[@]}"; do
            if ((octet < 0 || octet > 255)); then
                stat=1
                return $stat
            fi
        done
        stat=0
    fi

    return $stat
}

# Fonction pour afficher les bases de données
function show_databases() {
    mysql -u "$MYSQL_USER" -p"$MYSQL_PASS" -e "SHOW DATABASES;" 2>/dev/null
    if [ $? -ne 0 ]; then
        echo "Erreur : Impossible de se connecter à MySQL. Vérifiez vos identifiants."
        exit 1
    fi
}

# Fonction pour afficher toutes les informations de la table "equipements"
function show_all_info() {
    local db_name=$1
    mysql -u "$MYSQL_USER" -p"$MYSQL_PASS" -D "$db_name" -e "SELECT * FROM equipements;" 2>/dev/null
    if [ $? -ne 0 ]; then
        echo "Erreur : Impossible d'accéder à la base de données '$db_name' ou à la table 'equipements'."
        exit 1
    fi
}

# Fonction pour envoyer un ping à une IP spécifique
function ping_ip() {
    local ip=$1
    if is_valid_ip "$ip"; then
        echo "Pinging $ip..."
        ping -c 4 "$ip"
    else
        echo "Erreur : '$ip' n'est pas une adresse IP valide."
    fi
}

# Demander quel type de ping l'utilisateur souhaite effectuer
echo "Choisissez le type de ping :"
echo "1) Pinger une adresse IP depuis la base de données"
echo "2) Pinger une adresse IP d'Internet"
read -p "Entrez votre choix (1 ou 2) : " choice

if [ "$choice" -eq 1 ]; then
    echo "Bases de données disponibles :"
    show_databases

    read -p "Entrez le nom de la base de données : " db_name

    if [ -z "$db_name" ]; then
        echo "Erreur : Vous devez entrer un nom de base de données."
        exit 1
    fi

    echo "Informations dans la table 'equipements' de la base '$db_name' :"
    show_all_info "$db_name"

    read -p "Entrez l'ID de l'équipement à pinger : " equipement_id

    if ! [[ "$equipement_id" =~ ^[0-9]+$ ]]; then
        echo "Erreur : L'ID doit être un nombre entier."
        exit 1
    fi

    ip=$(mysql -u "$MYSQL_USER" -p"$MYSQL_PASS" -D "$db_name" -se \
        "SELECT adresse_ip FROM equipements WHERE Id = $equipement_id;" 2>/dev/null)

    if [ -z "$ip" ]; then
        echo "Aucune adresse IP trouvée pour l'ID $equipement_id."
    else
        ping_ip "$ip"
    fi

elif [ "$choice" -eq 2 ]; then
    read -p "Entrez l'adresse IP d'Internet à pinger : " internet_ip
    ping_ip "$internet_ip"
else
    echo "Erreur : Choix invalide. Veuillez entrer 1 ou 2."
    exit 1
fi









