#!/bin/bash

# Nom d'utilisateur MySQL
MYSQL_USER="votre_utilisateur"

# Demander le mot de passe MySQL une seule fois
read -sp "Entrez le mot de passe MySQL : " MYSQL_PASS
echo

# Fonction pour afficher les bases de données
function show_databases() {
    mysql -u $MYSQL_USER -p$MYSQL_PASS -e "SHOW DATABASES;"
}

# Fonction pour afficher toutes les informations de la table "equipements"
function show_all_info() {
    local db_name=$1
    mysql -u $MYSQL_USER -p$MYSQL_PASS -D $db_name -e "SELECT * FROM equipements;"
}

# Fonction pour tester la connectivité à un port TCP
function test_tcp_port() {
    local ip=$1
    local port=$2
    echo "Testing TCP connection to $ip on port $port..."
    nc -z -v $ip $port
}

# Demander quel type de test l'utilisateur souhaite effectuer
echo "Choisissez le type de test :"
echo "1) Tester un port TCP d'une adresse IP de la base de données"
echo "2) Tester un port TCP d'une adresse IP d'Internet"
read -p "Entrez votre choix (1 ou 2) : " choice

if [ "$choice" -eq 1 ]; then
    # Demander à l'utilisateur de choisir une base de données
    echo "Voici les bases de données disponibles :"
    show_databases

    read -p "Entrez le nom de la base de données que vous souhaitez utiliser : " db_name

    # Afficher toutes les informations
    echo "Voici toutes les informations dans la table 'equipements' de la base de données '$db_name' :"
    show_all_info $db_name

    # Demander à l'utilisateur de choisir un ID
    read -p "Entrez l'ID de l'équipement dont vous souhaitez tester le port : " equipement_id

    # Récupérer l'adresse IP et le port correspondant à l'ID choisi
    read -r ip port < <(mysql -u $MYSQL_USER -p$MYSQL_PASS -D $db_name -e "SELECT adresse_ip, port FROM equipements WHERE Id = $equipement_id;" | tail -n +2)

    if [ -z "$ip" ]; then
        echo "Aucune adresse IP trouvée pour l'ID $equipement_id."
    else
        # Tester la connectivité au port TCP
        test_tcp_port $ip $port
    fi
elif [ "$choice" -eq 2 ]; then
    # Demander à l'utilisateur de saisir une adresse IP d'Internet et un port
    read -p "Entrez l'adresse IP d'Internet que vous souhaitez tester : " internet_ip
    read -p "Entrez le port TCP que vous souhaitez tester : " internet_port
    test_tcp_port $internet_ip $internet_port
else
    echo "Choix invalide. Veuillez entrer 1 ou 2."
fi

